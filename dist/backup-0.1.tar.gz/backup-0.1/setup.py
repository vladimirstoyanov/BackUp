from distutils.core import setup

setup(name='backup',
      version='0.1',
      py_modules=['backup'],
      )